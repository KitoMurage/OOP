import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

// TODO: Implement the Shoe class in this file
public class Shoe {
    private List<BaccaratCard> shoe;
    public Shoe(int decks){
        if(decks != 6 && decks != 8){
            throw new CardException("Unexpected value");
        }
        shoe = new LinkedList<>();
        for (int i = 0; i < decks; i++) {
            for (BaccaratCard.Suit suit : BaccaratCard.Suit.values()) {
                for (BaccaratCard.Rank rank : BaccaratCard.Rank.values()) {
                    shoe.add(new BaccaratCard(rank, suit));
                }
            }
        }

    }
    public int size(){
        return shoe.size();
    }
    public void shuffle(){
        Collections.shuffle(shoe);
    }
    public Card deal(){
        if (shoe.isEmpty()) {
            throw new CardException("Shoe is empty. Cannot deal any more cards.");
        }
        return shoe.remove(0);
    }
}
