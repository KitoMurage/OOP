public class BaccaratCard extends Card {

    public BaccaratCard(Rank r, Suit s) {
        super(r, s);
    }


    public Rank getRank() {
        return super.getRank();
    }


    public Suit getSuit() {
        return super.getSuit();
    }


    public String toString() {
        return String.format("%c%c", this.getRank().getSymbol(), this.getSuit().getSymbol());
    }


    public boolean equals(Object other) {

        if (other == this) {
            return true;
        }
        else if (other instanceof BaccaratCard) {
            final BaccaratCard card = (BaccaratCard) other;
            return this.getRank() == card.getRank() && this.getSuit() ==  card.getSuit();
        }
        return false;
    }


    public int compareTo(Card other) {
        int difference = this.getSuit().compareTo(other.getSuit());
        if (difference == 0) {
            difference = this.getRank().compareTo(other.getRank());
        }

        return difference;
    }


    public int value() {
        switch (getRank()) {
            case TWO:
            case THREE:
            case FOUR:
            case FIVE:
            case SIX:
            case SEVEN:
            case EIGHT:
            case NINE:
                return Math.min(getRank().ordinal() + 1, 10);
            case TEN:
            case JACK:
            case QUEEN:
            case KING:
                return 0;
            case ACE:
                return 1;
            default:
                throw new IllegalStateException("Unexpected value: " + getRank());
        }
    }
}
