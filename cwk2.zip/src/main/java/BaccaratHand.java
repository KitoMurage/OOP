// TODO: Implement the BaccaratHand class in the file

import java.util.LinkedList;
import java.util.List;
public class BaccaratHand {
    protected List<BaccaratCard> baccaratCards;
    public BaccaratHand(){
        baccaratCards = new LinkedList<>();
    }
    public int size(){
        return baccaratCards.size();
    }
    public void add(BaccaratCard card){
        baccaratCards.add(card);
    }
    public int value(){
        int sum = 0;
        for (BaccaratCard card: baccaratCards) {
            sum += card.value();
        }
        return sum % 10;
    }
    public boolean isNatural(){
        return baccaratCards.size() == 2 && (value() == 8 || value() == 9);
    }
    public String toString(){
        String result = "";
        for (BaccaratCard card : baccaratCards) {
            String sf;
            sf = String.format("%c%c ", card.getRank().getSymbol(), card.getSuit().getSymbol());
            result += String.format(sf);
        }
        return result.trim();

    }

}
