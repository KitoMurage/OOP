import java.io.FileOutputStream;
import java.io.PrintStream;
import java.io.FileDescriptor;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class Baccarat {
  public static void main(String[] args) {
    System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out), true, StandardCharsets.UTF_8));

    if (args.length > 0 && ("-i".equals(args[0]) || "--interactive".equals(args[0]))) {
      interactiveMode();
    } else {
      nonInteractiveMode();
    }
  }
  public static void interactiveMode() {
    int numRounds = 0;
    int playerWins = 0;
    int bankerWins = 0;
    int ties = 0;

    Scanner scanner = new Scanner(System.in);
    boolean continuePlaying = true;

    while (continuePlaying) {
      numRounds++;
      System.out.println("Round " + numRounds + ":");

      // Create a shoe with 6 decks and shuffle it
      Shoe shoe = new Shoe(6);
      shoe.shuffle();

      // Deal cards to the player and banker
      BaccaratHand playerHand = new BaccaratHand();
      BaccaratHand bankerHand = new BaccaratHand();
      for (int i = 0; i < 2; i++) {
        playerHand.add((BaccaratCard) shoe.deal());
        bankerHand.add((BaccaratCard) shoe.deal());
      }

      System.out.println("Player's Hand: " + playerHand + " = " + playerHand.value());
      System.out.println("Banker's Hand: " + bankerHand + " = " + bankerHand.value());

      // Check for naturals
      if (playerHand.isNatural()) {
        System.out.println("Player has a Natural!");
      }
      if (bankerHand.isNatural()) {
        System.out.println("Banker has a Natural!");
      }
      int playerThirdCardValue = 0;

      // Apply drawing rules for player and banker

      // Player's Turn
      if (playerHand.value() <= 5) {
        // Player draws a third card
        System.out.println("Dealing third card to player...");
        BaccaratCard playerThirdCard = (BaccaratCard) shoe.deal();
        playerHand.add(playerThirdCard);
        playerThirdCardValue = playerThirdCard.value();
      }
      if (playerHand.size() == 2) {
        // Player has stood pat, banker acts according to player's hand
        if (playerHand.value() <= 5) {
          // Banker draws a third card
          System.out.println("Dealing third card to banker...");
          bankerHand.add((BaccaratCard) shoe.deal());
        }

        // Determine the value of the player's third card
        if (playerHand.size() == 3) {
          if (bankerHand.value() <= 2) {
            System.out.println("Dealing third card to banker...");
            bankerHand.add((BaccaratCard) shoe.deal());
          } else if (bankerHand.value() == 3) {
            if (playerThirdCardValue != 8) {
              System.out.println("Dealing third card to banker...");
              bankerHand.add((BaccaratCard) shoe.deal());
            }
          } else if (bankerHand.value() == 4) {
            if (playerThirdCardValue >= 2 && playerThirdCardValue <= 7) {
              System.out.println("Dealing third card to banker...");
              bankerHand.add((BaccaratCard) shoe.deal());
            }
          } else if (bankerHand.value() == 5) {
            if (playerThirdCardValue >= 4 && playerThirdCardValue <= 7) {
              System.out.println("Dealing third card to banker...");
              bankerHand.add((BaccaratCard) shoe.deal());
            }
          } else if (bankerHand.value() == 6) {
            if (playerThirdCardValue == 6 || playerThirdCardValue == 7) {
              System.out.println("Dealing third card to banker...");
              bankerHand.add((BaccaratCard) shoe.deal());
            }
          }
        }
      }

      String roundResult;
      if (playerHand.isNatural() || bankerHand.isNatural()) {
        if (playerHand.isNatural() && !bankerHand.isNatural()) {
          roundResult = "Player win!";
        } else if (bankerHand.isNatural() && !playerHand.isNatural()) {
          roundResult = "Banker win!";
        } else {
          roundResult = "Tie";
        }
      } else {
        int playerTotal = playerHand.value();
        int bankerTotal = bankerHand.value();
        if (playerTotal > bankerTotal) {
          roundResult = "Player win!";
        } else if (playerTotal < bankerTotal) {
          roundResult = "Banker win!";
        } else {
          roundResult = "Tie";
        }
      }

      System.out.println(roundResult);
      if (roundResult.equals("Player win!")) {
        playerWins++;
      } else if (roundResult.equals("Banker win!")) {
        bankerWins++;
      } else {
        ties++;
      }

      // Ask the user if they want to continue
      System.out.print("Another round? (y/n): ");
      String userInput = scanner.nextLine().trim().toLowerCase();
      if (!userInput.startsWith("y")) {
        continuePlaying = false;
      }
    }

    // Display end-of-game statistics
    System.out.println(numRounds + " rounds played");
    System.out.println(playerWins + " player wins");
    System.out.println(bankerWins + " banker wins");
    System.out.println(ties + " ties");
  }
  public static void nonInteractiveMode() {

    int playerWins = 0;
    int bankerWins = 0;
    int ties = 0;

    int numRounds = 10; // Define the number of rounds to play

    // Create a shoe with 6 decks and shuffle it
    Shoe shoe = new Shoe(6);
    shoe.shuffle();

    for (int round = 1; round <= numRounds; round++) {
      System.out.println("Round " + round + ":");

      // Deal cards to the player and banker
      BaccaratHand playerHand = new BaccaratHand();
      BaccaratHand bankerHand = new BaccaratHand();
      for (int i = 0; i < 2; i++) {
        playerHand.add((BaccaratCard) shoe.deal());
        bankerHand.add((BaccaratCard) shoe.deal());
      }

      System.out.println("Player's Hand: " + playerHand + " = " + playerHand.value());
      System.out.println("Banker's Hand: " + bankerHand + " = " + bankerHand.value());

      // Check for naturals
      if (playerHand.isNatural()) {
        System.out.println("Player has a Natural!");
      }
      if (bankerHand.isNatural()) {
        System.out.println("Banker has a Natural!");
      }
      int playerThirdCardValue = 0;

      // Apply drawing rules for player and banker
      // TODO: Implement drawing rules
      // Player's Turn
      if (playerHand.value() <= 5) {
        // Player draws a third card
        System.out.println("Dealing third card to player...");
        BaccaratCard playerThirdCard = (BaccaratCard) shoe.deal();
        playerHand.add(playerThirdCard);
        playerThirdCardValue = playerThirdCard.value();
      }
      if (playerHand.size() == 2) {
        // Player has stood pat, banker acts according to player's hand
        if (playerHand.value() <= 5) {
          // Banker draws a third card
          System.out.println("Dealing third card to banker...");
          bankerHand.add((BaccaratCard) shoe.deal());
        }


// Determine the value of the player's third card

        if (playerHand.size() == 3){
          if(bankerHand.value() <= 2){
            System.out.println("Dealing third card to banker...");
            bankerHand.add((BaccaratCard) shoe.deal());
          }
          else if(bankerHand.value() == 3){
            if(playerThirdCardValue != 8){
              System.out.println("Dealing third card to banker...");
              bankerHand.add((BaccaratCard) shoe.deal());}}

          else if(bankerHand.value() == 4){
            if(playerThirdCardValue >= 2 && playerThirdCardValue <= 7){
              System.out.println("Dealing third card to banker...");
              bankerHand.add((BaccaratCard) shoe.deal());}}

          else if(bankerHand.value() == 5){
            if(playerThirdCardValue >= 4 && playerThirdCardValue <= 7){
              System.out.println("Dealing third card to banker...");
              bankerHand.add((BaccaratCard) shoe.deal());}}

          else if(bankerHand.value() == 6){
            if(playerThirdCardValue == 6 || playerThirdCardValue == 7){
              System.out.println("Dealing third card to banker...");
              bankerHand.add((BaccaratCard) shoe.deal());}}


        }
      }

      String roundResult;
      if (playerHand.isNatural() || bankerHand.isNatural()) {
        if (playerHand.isNatural()) {
          roundResult = "Player win!";
        } else {
          roundResult = "Banker win!";
        }
      } else {
        int playerTotal = playerHand.value();
        int bankerTotal = bankerHand.value();

        if (playerTotal > bankerTotal) {
          roundResult = "Player win!";
        } else if (playerTotal < bankerTotal) {
          roundResult = "Banker win!";
        } else {
          roundResult = "Tie";
        }
      }

      System.out.println(roundResult);
      if (roundResult.equals("Player win!")) {
        playerWins++;
      } else if (roundResult.equals("Banker win!")) {
        bankerWins++;
      } else {
        ties++;
      }
    }


    // Display end-of-game statistics

    System.out.println(numRounds + " rounds played");
    System.out.println(playerWins + " player wins");
    System.out.println(bankerWins + " banker wins");
    System.out.println(ties + " ties" );
  }
}
